import sys
from typing import Callable
import numpy as np

def snr2value(snr: float, noisePow: float):
    """
    return the amplitude of signal whose snr is snr. assuming the 
    signal is complex signal.
    snr -- the snr of signal.
    noisePow -- the power of the noise.
    """
    ratio = np.power(10, snr / 10)
    signalPow = noisePow * ratio
    return np.sqrt(signalPow)

def hermitian(array: np.ndarray):
    """
    return the hermitian of the array.
    """
    return np.conjugate(array.T)

def calCov(array: np.ndarray):
    """
    return the covariance matrix of the array, that is, 
    array @ hermitian(array) / len(array[0]) .
    """
    return (array @ hermitian(array)) / len(array[0])

def mvdr(output: np.ndarray, expectTheta: float, aTheta: Callable, diagLoad:float=0):
    alpha0 = aTheta(expectTheta)
    covMat = calCov(output)
    covMat = covMat + np.eye(len(covMat)) * diagLoad
    return np.linalg.pinv(covMat, hermitian=True) @ alpha0

def spatialSmooth(output: np.ndarray, expectTheta: float, aTheta: Callable, subarraySize: int, diagLoad:float=0):
    """
    the spatial smooth (SS) algorithm.
    output -- the signals on the array.
    expectTheta -- the theta of expect signal.
    aTheta -- the a(theta) function
    subarraySize -- elements number of the subarray.
    """
    alpha0 = aTheta(expectTheta)
    alpha0 = alpha0[:subarraySize, :]

    cov = calCov(output)
    subCov = []
    for k in range(len(output) - subarraySize + 1):
        subCov.append(cov[k:k+subarraySize, k:k+subarraySize])
    smoothedCov = sum(subCov) / len(subCov)

    smoothedCov = smoothedCov + np.eye(subarraySize) * diagLoad

    return np.linalg.pinv(smoothedCov, hermitian=True) @ alpha0

def response(weight: np.ndarray, thetas: np.ndarray, responseFunc: Callable, minValue=-70):
    """
    the fuction to calculate the response at every theta in thetas.
    weight -- the weight vector, which is a nx1 numpy ndarray.
    thetas -- 1 dimension numpy ndarray, contains all the thetas whose response
            need to be calculated.
    responseFunc -- the a(theta) function.
    """
    res = []
    for theta in thetas:
        res.append((hermitian(weight) @ responseFunc(theta)).item())
    res = np.array(res)
    res = np.abs(res)
    res = res / max(np.max(res), sys.float_info.min)
    res = 20 * np.log10(res)
    res[res < minValue] = minValue
    return res

def responsePhase(weight: np.ndarray, thetas: np.ndarray, responseFunc: Callable):
    """
    the fuction to calculate the response at every theta in thetas.
    weight -- the weight vector, which is a nx1 numpy ndarray.
    thetas -- 1 dimension numpy ndarray, contains all the thetas whose response
            need to be calculated.
    responseFunc -- the a(theta) function.
    """
    res = []
    for theta in thetas:
        res.append((hermitian(weight) @ responseFunc(theta)).item())
    res = np.array(res)
    res = np.angle(res)
    return res

def calPow(signal: np.ndarray):
    """
    return the power of the signal.
    """
    return sum(np.conjugate(signal) * signal) / len(signal)
